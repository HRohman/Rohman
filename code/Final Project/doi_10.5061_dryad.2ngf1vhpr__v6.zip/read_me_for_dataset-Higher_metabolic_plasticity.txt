﻿This Description file of data uploaded in 'Higher metabolic plasticity in temperate compared to tropical lizards suggests increased resilience to climate change' readme.txt file was generated on 2021-12-17 by Baojun Sun



GENERAL INFORMATION

1. Title of Dataset: 
Data and supporting information from: Higher metabolic plasticity in temperate compared to tropical lizards suggests increased resilience to climate change

2. Author Information
	A. Principal Investigator Contact Information
		Name: Baojun Sun	
		Institution: Key Laboratory of Animal Ecology and Conservation Biology, Institute of Zoology, Chinese Academy of Sciences, Beijing 100101, China
		Address:  Beichen West Road, Chaoyang District, Beijing, China  
		Email: sunbaojun@ioz.ac.cn

	B. Associate or Co-investigator Contact Information
		Name: Weiguo Du	
		Institution: Key Laboratory of Animal Ecology and Conservation Biology, Institute of Zoology, Chinese Academy of Sciences, Beijing 100101, China
		Address:  Beichen West Road, Chaoyang District, Beijing, China  
		Email: duweiguo@ioz.ac.cn

	C. Alternate Contact Information
		Name: 
		Institution: 
		Address: 
		Email: 

3. Date of data collection (single date, range, approximate date): 
From 2014-04 to 2018-08 

4. Geographic location of data collection : 
The data were from the lizards collected from three Takydromu lizards across latitudes:
T. sexlineatus from Zhaoqing in Guangdong; 
T. septentrionalis from Wenzhou in Zhejiang;
T. wolteri from Chuzhou  in Anhui.

5. Information about funding sources that supported the collection of the data: 
The data collected in this work was supported by grants from the National Natural Science Foundation of China (31720103904 and 31821001 for W. G. Du, and 31870391 for B. J. Sun). 
B. J. Sun is also supported by Youth Innovation Promotion Association CAS (no.2019085). 

SHARING/ACCESS INFORMATION

1. Licenses/restrictions placed on the data: If you make extensive use of data from this data set, please credit the authors.

2. Links to publications that cite or use the data: Ecological Monographs

3. Links to other publicly accessible locations of the data: no

4. Links/relationships to ancillary data sets: no

5. Was data derived from another source? yes/no
	A. If yes, list source(s): no

6. Recommended citation for this dataset: 
Sun, Bao-jun et al. (2022), Data and supporting information from: Higher metabolic plasticity in temperate compared to tropical lizards suggests increased resilience to climate change, Dryad, Dataset, DOI: 10.5061/dryad.2ngf1vhpr




DATA & FILE OVERVIEW

1. File List: 
Growth:    Morphology and growth of lizards under cold and warm treatments
MR:    Metabolic rates, respiration exchange rate and thermal sensitivity of lizards under cold and warm treatments
Organ size:    Liver, brain and heart mass of lizards under cold and warm treatments
S3, S4 and COX:    State 3, State 4 mitochondrial respiration and COX activities of lizards liver under cold and warm treatments
Ta:    Body tempertatures of lizards under cold and warm treatments
Te-acclimation:    Ambient temperatures for lizards under cold and warm treatments
Data S1:    Characteristics of peptides of proteomic analysis
Data S2:    Differentially expressed proteins (DEPs) of lizards under cold and warm treatments
Data S3:    Specific GO enrichments of DEPs of each lizard under cold and warm treatments
Data S4:    Metabolism related DEPs in lizards under cold and warm treatments
Data S5:    DEPs in metabolic pathways of carbohydrate, fatty acid, and amino acid
Data S6:    Identified peaks in metabolomics of lizard lives 

2. Relationship between files, if important: 
no

3. Additional related data collected that was not included in the current data package: 
no

4. Are there multiple versions of the dataset? yes/no
	A. If yes, name of file(s) that was updated: 
		i. Why was the file updated? 
		ii. When was the file updated? 
no


METHODOLOGICAL INFORMATION

1. Description of methods used for collection/generation of data: 
Details in data collection were provided in 'materials and methods' of the related paper and appendices

2. Methods for processing the data: 
the data were collected and calculated by the processes described in 'materials and methods' of the related paper

3. Instrument- or software-specific information needed to interpret the data: 
All analyses were conducted using SPSS 21.0. The methods usedwere described in the Materials and Methods of the related paper. 

4. Standards and calibration information, if appropriate:  
no

5. Environmental/experimental conditions: 
see details in 'materials and methods'

6. Describe any quality-assurance procedures performed on the data: 
no 

7. People involved with sample collection, processing, analysis and/or submission: 
B. J. Sun, and T. Li designed the methodology; 
B. J. Sun, C. Williams, T. Li, Z. G. Jin, H. L. Lu, and L. G. Luo collected the data;
B. J. Sun, C. Williams, W. G. Du and J. Speakman analyzed data.


DATA-SPECIFIC INFORMATION FOR: [growth]

1. Number of variables: 13

2. Number of cases/rows: 94

3. Variable List:
Species = species name
No. = individual mark of lizards
Treatment = cold or warm treatment
Sex = sex information 
ini-SVL = initial snout-vent length of the lizard before acclimation
ini-TL = initial tail length of the lizard before acclimation
ini-BM = initial body mass of the lizard before acclimation
fin-SVL = final snout-vent length of the lizard after acclimation
fin-TL = final tail length of the lizard after acclimation
fin-BM = final body mass of the lizard after acclimation
days = days span the acclimation for lizards
Gowth rate-SVL = growth rate in snout-vent length of lizards
Gowth rate-BM = growth rate in body mass of lizards



DATA-SPECIFIC INFORMATION FOR: [MR]

1. Number of variables: 17

2. Number of cases/rows: 82

3. Variable List:
ID = individual mark of lizards
Species = species name	
BM(g) =  body mass of the lizard	
Sex = sex information
Treatment = cold or warm treatment
RMR18C(ml/g/hr)	-RMR-38C(ml/g/hr) = resting metabolic rates of lizards under cold and warm treatments at 18 -38℃
k38/18 = reaction rate of 38C against 18C	
Q10 = thermal sensitivities of RMR 
RER-18C-RER-38C= respiration exchange rate of resting metabolic rates of lizards under cold and warm treatments at 18 -38℃

		

DATA-SPECIFIC INFORMATION FOR: [Organ size]

1. Number of variables: 9

2. Number of cases/rows: 36

3. Variable List:
ID = individual mark of lizards
Species = species name	
Treatment = cold or warm treatment	
Sex = sex information
BM(g) =  body mass of the lizard	
Heart mass = heart mass of lizards under cold and warm treatments	
Brain mass = brain mass of lizards under cold and warm treatments	
Liver Mass = liver mass of lizards under cold and warm treatments		
MP(mg/g protein) = mitochondrial protein concentration


DATA-SPECIFIC INFORMATION FOR: [S3, S4 and COX]

1. Number of variables: 21

2. Number of cases/rows: 36

3. Variable List:
ID = individual mark of lizards
Species = species name	
Treatment = cold or warm treatment	
Sex = sex information	
Liver mass = liver mass of lizards under cold and warm treatments	
S3-18C — S3-38C = State 3 mitochondrial respirations of lizard liver under cold and warm treatments at 18 -38℃	
S4-18C — S4-38C = State 4 mitochondrial respirations of lizard liver under cold and warm treatments at 18 -38℃		
COX-18C — COX-38C = COX activities of lizard liver under cold and warm treatments at 18 -38℃	
protein concentration (mg/g tissue) = mitochondrial protein concentration


DATA-SPECIFIC INFORMATION FOR: [Ta]

1. Number of variables: 17

2. Number of cases/rows: 60

3. Variable List:
ID = individual mark of lizards
Species = species name	
Treatment = cold or warm treatment		
Ta-7 — Ta 19 = active body temperatures from 7 to 19 o' clock
mean-Ta = daily average active body temperatures


DATA-SPECIFIC INFORMATION FOR: [Te-acclimation]

1. Number of variables: 4 + 9

2. Number of cases/rows: 1967 + 24

3. Variable List:
For sheet of 'Hourly':
Date = date of the temperature collection	
Time = time of the temperature collection	
mean-warm = average ambient temperatures for lizards under warm treatment 	
mean-cold = average ambient temperatures for lizards under cold treatment

For sheet of 'Daily':
Time（o'clock）= daily time of the temprature collection	
Warm-Twolteri = average temperatures for T. wolteri under warm treatment	
Warm-Tseptentrionalis = average temperatures for T. septentrionalis under warm treatment		
Warm-Tsexlineatus = average temperatures for T. sexlineatus under warm treatment		
Mean-warm = average temperature for three lizards under warm treatment	
Cold-Twolteri = average temperatures for T. wolteri under cold treatment		
Cold-Tseptentrionali s= average temperatures for T. wolteri under cold treatment		
Cold-Tsexlineatus = average temperatures for T. wolteri under cold treatment	
Mean-cold = average temperature for three lizards under cold treatment


DATA-SPECIFIC INFORMATION FOR: [Data S1 Characteristics of peptides]

1. Number of variables: 11

2. Number of cases/rows: 669

3. Variable List:
Accession = number of the protein in datasets	  
Description = Provides the name of the protein exclusive of the identifier that appears in the Accession column.	
Score = Displays the protein score, which is the sum of the scores of the individual peptides	
Coverage = Displays by default the percentage of the protein sequence covered by identified peptides.
# Proteins = Displays the number of identified proteins in the protein group of a master protein	
# Unique Peptides = Displays the number of peptide sequences unique to a protein group.
# Peptides = Displays the number of distinct peptide sequences in the protein group.	
# PSMs = Displays the total number of identified peptide sequences (peptide spectrum matches) for the protein, including those redundantly identified.	
# AAs = Shows by default the sequence length of the protein.	
MW [kDa] = Displays the calculated molecular weight of the protein.	
calc. pI = Displays the theoretically calculated isoelectric point, which is the pH at which a particular molecule carries no net electrical charge.
										

DATA-SPECIFIC INFORMATION FOR: [Data S2 Differentially expressed proteins (DEPs)]

1. Number of variables: 5

2. Number of cases/rows: 660

3. Variable List:
Accession = number of the protein in datasets	  
Description = Provides the name of the protein exclusive of the identifier that appears in the Accession column.		
Cold/Warm-T.sexlineatus = differentially expressed proteins of cold compared to warm treatment in T. sexlineatus	
Cold/Warm-T.septentrionalis= differentially expressed proteins of cold compared to warm treatment in T. septentrionalis	
Cold/Warm-T.wolteri= differentially expressed proteins of cold compared to warm treatment in T. wolteri


DATA-SPECIFIC INFORMATION FOR: [Data S3 Specific GO enrichment]

1. Number of variables: 7 + 7 + 7

2. Number of cases/rows: 20

3. Variable List:
For sheet of 'T.wolteri':
No# =  series number of the GO enrichment	
MF = Molecular functions	
Number of Proteins-MF =  number of proteins enriched in molecular functions	
BP = Biological processes	
Number of Proteins-BP = number of proteins enriched in biological processes	
CC = cellular components	
Number of Proteins-CC = number of proteins enriched in cellular components

For sheet of 'T.sexlineatus':
No# =  series number of the GO enrichment	
MF = Molecular functions	
Number of Proteins-MF =  number of proteins enriched in molecular functions	
BP = Biological processes	
Number of Proteins-BP = number of proteins enriched in biological processes	
CC = cellular components	
Number of Proteins-CC = number of proteins enriched in cellular components

For sheet of 'T. septentrionalis':
No# =  series number of the GO enrichment	
MF = Molecular functions	
Number of Proteins-MF =  number of proteins enriched in molecular functions	
BP = Biological processes	
Number of Proteins-BP = number of proteins enriched in biological processes	
CC = cellular components	
Number of Proteins-CC = number of proteins enriched in cellular components


DATA-SPECIFIC INFORMATION FOR: [Data S4 Metabolism-related DEPs]

1. Number of variables: 7

2. Number of cases/rows: 91

3. Variable List:
Category = category of carbohydrate, fatty acid, amino acid and ETC metabolism
Accession = number of the protein in datasets	
Description = name of the protein exclusive of the identifier that appears in the Accession column
Cold/warm-T.sexlineatus = Differentially expressed ratio of the protein in cold compared to warm treaments in T.sexlineatus
Cold/Warm-T.septentrionalis = Differentially expressed ratio of the protein in cold compared to warm treaments in T.septentrionalis	
Cold/Warm-T.wolteri = Differentially expressed ratio of the protein in cold compared to warm treaments in T.wolteri
Comments = comments in the datasets


DATA-SPECIFIC INFORMATION FOR: [Data S5 DEPs in metabolic pathways]

1. Number of variables: 5

2. Number of cases/rows: 201

3. Variable List:
ACC No. = accession number of the protein and the categories of the proteins related	
Protein description = name of the protein 	
Cold/warm-T.sexlineatus = Differentially expressed ratio of the protein in cold compared to warm treaments in T.sexlineatus
Cold/Warm-T.septentrionalis = Differentially expressed ratio of the protein in cold compared to warm treaments in T.septentrionalis	
Cold/Warm-T.wolteri = Differentially expressed ratio of the protein in cold compared to warm treaments in T.wolteri


DATA-SPECIFIC INFORMATION FOR: [Data S6 Identified peaks in metabolites]

1. Number of variables: 6

2. Number of cases/rows: 488

3. Variable List:
Peaks = name of the analyte in 'Fiehn' database	
Analyte = Id number of the Analyte
Similarity	 = scores that evaluate the similarity of the Analyte to peaks (0-1000)
R.T. (minutes) = retain times 	of the Analyte
Count = how many times of the Analyte was detected in mass spectrum
Mass = mass to charge ratio of molecular ions on a mass spectrum
