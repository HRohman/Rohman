
library(inbreedR)
library(vcfR)
library(reshape2)

vcf_file <- 'lenRefgenome_LD_100_bi.recode.vcf'

# read vcf
vcf <- read.vcfR(vcf_file, verbose = FALSE )
# extract genotypes
gt <- extract.gt(vcf)
# transpose and data.frame
gt <- as.data.frame(t(gt), stringsAsFactors = FALSE)
# NA handling
gt[gt == "."] <- NA
# split columns
snp_geno <- do.call(cbind, apply(gt, 2, function(x) colsplit(x, "/", c("a","b"))))
# convert
HL_snp_genotypes <- inbreedR::convert_raw(snp_geno)

check_data(HL_snp_genotypes)

# Get overall heterozygosity
Het <- MLH(HL_snp_genotypes)

## Then do this per population by extracting the individuals from the vcf
## To do this you get the names of your gt object, rename the rows of the genotypes dataframe
### Then you select per population and redo the calculations