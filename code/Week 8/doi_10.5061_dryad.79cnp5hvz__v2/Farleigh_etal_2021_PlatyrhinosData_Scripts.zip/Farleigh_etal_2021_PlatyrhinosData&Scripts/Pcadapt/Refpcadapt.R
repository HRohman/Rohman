
library(vcfR)
library(pcadapt)
library(qvalue)

# pcadapt is used to test for outliers and useful in terms of visualization as well

### Set Colors 

colors = c("ForestGreen", "Gold", "Limegreen")

###########################################################
##### Run pcadapt #########################################
###########################################################

###############################################################
# First step is to determine the number of principal components
###############################################################

Genotypes<- read.pcadapt("lenRef.pcadapt")
x <- pcadapt(Genotypes, K = 20) 
plot(x, option = "screeplot")
x <- pcadapt(Genotypes, K = 15)
plot(x, option = "screeplot")
# run pca and plot the resulting screeplot
# look for the knee in the plot

Pops<- read.csv("HLReferenceSamples_EnvdataRDA.csv")
Pops<- Pops$Population
Pops<-as.character(Pops)
# create a vector that contains the names of populations and how many individuals are in each
# this preps for you to project your PCA

plot(x, option = "scores", pop = Pops)
plot(x, option = "scores", pop = Pops, plt.pkg = "plotly")
# project your PCA with corresponding colors
# use plotly code for an interactive plot

plot(x, option = "scores", i = 3, j = 4, pop = Pops)
# you can plot multiple principal components 
# for example here we plot 3 & 4, as compared to 1 & 2 in the first example

##############################################
# Second step is to compute our test statistic
##############################################

x <- pcadapt(Genotypes, K = 12)
#run based on your choice of K value

summary(x)
#look at your run


#####################################
# Third step is to graph your results
#####################################

plot(x , option = "manhattan")
# creates a manhattan plot from your run

plot(x, option = "qqplot", threshold = 0.1)
# creates a qqplot from your run
# looking for most pvalues to be expected but some to stray on the side of signifigance 

plot(x, option = "stat.distribution")
# Plot the Mahalanobis distance

hist(x$pvalues, xlab = "p-values", main = NULL, breaks = 50, col = "navy")
# plot a histogram of the pvalues, want to see a uniform distribution

###################################
# Fourth step is to choose a cutoff
###################################

# view Storey 2010 for a good explination of q-values

qval <- qvalue(x$pvalues)$qvalues
alpha <- 0.01
outliersQ <- which(qval < alpha)
outliers = which(qval < alpha)
length(outliersQ)

Qvalue<-as.data.frame(outliersQ)
candSNP = Qvalue
candSNP = as.data.frame(unlist(candSNP))
colnames(candSNP)<- "Position"
Mapped<- inner_join(candSNP, SNPs, by = "Position")

write.csv(Qvalue, file = "QOutliers.csv")
# tests for SNPs with a qvalue less than 0.1
# gives us how many outliers were detected

######################################
##### Now let's make a cool plot #####
######################################

plot(-log10(x$pvalues), main = "Manhattan Plot", xlab = "SNP Id", ylab = "-log10(P-values)", cex = 0.75, col = "grey")
points(Qvalue, -log10(x$pvalues)[outliers], pch = 19, cex = 0.75, col = "blue")
