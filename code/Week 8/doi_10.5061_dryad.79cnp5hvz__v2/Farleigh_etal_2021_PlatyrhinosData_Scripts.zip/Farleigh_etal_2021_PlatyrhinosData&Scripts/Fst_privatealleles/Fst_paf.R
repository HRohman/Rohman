library(vcfR)
library(inbreedR)
library (stringi)
library(reshape2)
library(hierfstat)
library(poppr)
library(ggplot2)
library(lmPerm)
library(ggpubr)
library(vegan)
library(FSA)
library(dunn.test)


###############################
###############################
###############################


#Fst and environmental and geographic distance multiple regressions

platyVCF <- read.vcfR(file="lenRefgenome_LD.vcf")
platyVCF[samples = c(2, 3, 5:13, 16:27, 29:32, 35:39, 41:48, 52:62)] -> morethan2
write.vcf(morethan2, file="morethan2_lenRef_LD.vcf")
read.vcfR(file="morethan2_lenRef_LD.vcf")-> morethan2_lenRef_LD
morethan2_lenRef_LD
platyGenid <- vcfR2genind(morethan2_lenRef_LD)
samples <- read.csv("fst_samples.csv")
pop <- samples[1] #using just locality as "pop"
platyH <- genind2hierfstat(platyGenid, pop=pop) #must assign pops for this conversion
platyFst2 <- genet.dist(platyH, method="WC84") 
platyFst2


###############Private Allele Frequency####################

platyVCF <- read.vcfR(file="lenRefgenome_LD.vcf")

#PAF: Three genetic clusters#
platyGenid <- vcfR2genind(platyVCF)
Pop <- read.csv("HLReferenceSamples_EnvdataRDA.csv")
platyGenid$pop = Pop$Population
paf <- private_alleles(platyGenid, report="data.frame")
ggplot(paf) + geom_tile(aes(x = population, y = allele, fill = count))
paf
write.csv(paf, file="private_alleles.csv")

#PAF: All Localities#
platyGenid <- vcfR2genind(platyVCF)
Pop <- read.csv("HLReferenceSamples_EnvdataRDA.csv")
platyGenid$pop = Pop$pop
paf <- private_alleles(platyGenid, report="data.frame")
ggplot(paf) + geom_tile(aes(x = population, y = allele, fill = count))
paf
write.csv(paf, file="private_alleles.csv")
paf_loc <- read.csv("private_alleles_locality.csv")
paf_loc_lr <- lm(paf_loc$Percentage_of_all_PA ~ paf_loc$Latitude)
summary(paf_loc_lr)
paf_loc_2 <- lm(paf_loc$Private_alleles ~ paf_loc$Latitude)
summary(paf_loc_2)
paf_all <-read.csv("private_alleles.csv")
paf_sw <- read.csv("paf_s_w.csv")
chisq.test(paf_sw$Private_Alleles)
paf_se <- read.csv("paf_s_e.csv")
chisq.test(paf_se$Private_Alleles)
paf_ew <- read.csv("paf_e_w.csv")
chisq.test(paf_ew$Private_Alleles)
paf_ew <- read.csv("paf_e_w.csv")
chisq.test(paf_ew$Private_Alleles, paf_ew$Non_Private_Alleles)



paf.aov <- aov(paf_all$Private_Alleles ~ paf_all$Region, data=paf_all)
summary.aov(paf.aov)
TukeyHSD(paf.aov)


#PAF: Localities with at least 2 individuals#
platyVCF[samples = c(2, 3, 5:13, 16:27, 29:32, 35:39, 41:48, 52:62)] -> morethan2
platyGenid <- vcfR2genind(morethan2)
Pop <- read.csv("fst_samples.csv")
platyGenid$pop = Pop$pop
paf <- private_alleles(platyGenid, report="data.frame")
ggplot(paf) + geom_tile(aes(x = population, y = allele, fill = count))
paf
write.csv(paf, file="private_alleles_morethan2_v3.csv")
##########################################################

samples2 <- read.csv("dist_lenRef.csv")
platyGeoDist <- dist(samples2) #removed duplicate localities so matches our Fst output
samples3<- read.csv("environdist_lenRef.csv")
AMT <- samples3[6] #Annual Mean Temperature per each locality
dist_AMT <- dist(AMT) 
#looking at variance in genetic distance
library(ecodist)
MRM(platyFst2 ~ platyGeoDist)
MRM(platyFst2 ~ dist_AMT)
MRM(platyFst2 ~ platyGeoDist + dist_AMT) 
MRM(linplatyFst2 ~ platyGeoDist)
MRM(linplatyFst2 ~ dist_AMT)
MRM(linplatyFst2 ~ platyGeoDist + dist_AMT)
MRM(linplatyFst2 ~ dist_AMT + platyGeoDist)
mantel(linplatyFst2 ~ dist_AMT + platyGeoDist) #?
mantel(platyFst2 ~ platyGeoDist)
mantel(linplatyFst2 ~ platyGeoDist)
plot(mgram(platyFst2, platyGeoDist))
mgram(platyFst2, platyGeoDist)
plot(mgram(linplatyFst2, platyGeoDist))
loc <- samples3[1]
m <- data.frame(t(combn(rownames(loc),2)), as.numeric(dist_AMT))
write.csv(m, "dist_AMT.csv")
b <- data.frame(t(combn(rownames(loc),2)), as.numeric(platyFst2))
write.csv(b, "WC84Fst1.csv")
o <- data.frame(t(combn(rownames(loc),2)), as.numeric(platyGeoDist))
write.csv(o, "geoDist.csv")

file <-read.csv("WC84Fst1_comp.csv")
x <- file[[1]]
y <- file[[2]]
wilcox.test(x,y)

file <-read.csv("WC84Fst1_comp3.csv")
pairwise.wilcox.test(file$fst, file$comp)
kruskal.test(file$fst ~ file$comp)
comp.aov <- aov(file$fst ~ file$comp, data=file)
summary.aov(comp.aov)
TukeyHSD(comp.aov)
plot(comp.aov, 1)
plot(comp.aov, 2)
aov_residuals <- residuals(object = comp.aov )
shapiro.test(x = aov_residuals )  


file <-read.csv("WC84Fst1_reg2.csv")
kruskal.test(file$fst ~ file$region)
pairwise.wilcox.test(file$fst, file$region)

file <-read.csv("fst_lenRef_LD_morethan2.csv")
kruskal.test(file$Fst ~ file$Region)
dunn.test(x=file$Fst, g=file$Region, kw=TRUE, method="bh")
pairwise.wilcox.test(file$Fst, file$Region)
c <- ggplot(file, aes(x = Region, y = Fst, fill=Region))+ 
  geom_boxplot(varwidth = TRUE)
c+scale_x_discrete(limits=c("West", "South", "East"))+scale_fill_manual(values=c("#228b22", "#FFFF00", "#00FF00"))+ theme_classic()+ theme(legend.position="none")+ labs(x = "Genetic Cluster")+ labs(y = "Fst")+ labs(title = "Within Cluster Pairwise Fst")
perm <- adonis(file$Fst ~ file$Region, data=file, permutations = 999, method="euclidean")
perm


fst.aovp <- aovp(file$Fst ~ file$Region, data=file)
summary(fst.aovp)
TukeyHSD(fst.aovp)

file <-read.csv("directional_fst_lenRef_LD_morethan2.csv")
kruskal.test(file$Fst ~ file$Region)
pairwise.wilcox.test(file$Fst, file$Region)
fst.aov <- aov(file$Fst ~ file$Region, data=file)
summary.aov(fst.aov)
TukeyHSD(fst.aov)
c <- ggplot(file, aes(x = Region, y = Fst))+ 
  geom_boxplot(varwidth = TRUE)
c+scale_x_discrete(limits=c("SvW", "SvE", "EvW"))+ theme_classic()+ theme(legend.position="none")+ labs(x = "Cluster Comparison")+ labs(y = "Fst")+ labs(title = "Among Cluster Pairwise Fst")
perm <- adonis(file$Fst ~ file$Region, data=file, permutations = 999, method="euclidean")
perm
dunn.test(x=file$Fst, g=file$Region, kw=TRUE, method="bh")
dunnTest(file$Fst ~ file$Region, data=file, method="bh")



file <-read.csv("het_lenRef2.csv")
pairwise.wilcox.test(file$het2, file$sample)
kruskal.test(file$het2 ~ file$sample)
het.aov <- aov(file$het2 ~ file$sample, data=file)
summary.aov(het.aov)
TukeyHSD(het.aov)
shapiro.test(file$het2)
with(file, tapply(file$het2, file$sample, shapiro.test))
plot(het.aov, 1)
plot(het.aov, 2)
aov_residuals <- residuals(object = het.aov )
shapiro.test(x = aov_residuals ) 
ggboxplot(file, x = "sample", y = "het2", color = "sample", order = c("W", "S", "E"), ylab = "Heterozygosity", xlab = "Genetic cluster")


file <-read.csv("het2_lenRef_LD_100_bi.csv")
pairwise.wilcox.test(file$het, file$region)
dunn.test(x=file$het, g=file$region, kw=TRUE, method="bh")
het.aov <- aov(file$het ~ file$region, data=file)
summary.aov(het.aov)
TukeyHSD(het.aov)
shapiro.test(file$het)
with(file, tapply(file$het, file$region, shapiro.test))
plot(het.aov, 1)
plot(het.aov, 2)
aov_residuals <- residuals(object = het.aov )
shapiro.test(x = aov_residuals )

perm <- adonis(file$het ~ file$region, data=file, permutations = 999, method="euclidean")
perm



bartlett.test(file$het ~ file$region, data=file)
install.packages("car")
library(car)
leveneTest(file$het ~ file$region, data=file)

#MLH visualize
file <-read.csv("het2_lenRef_LD_100_bi.csv")
file$region <- as.factor(file$region)
c <- ggplot(file, aes(x = region, y = het, fill=region))+ 
  geom_boxplot(varwidth = TRUE)
c
c+scale_x_discrete(limits=c("West", "South", "East"))+scale_fill_manual(values=c("#228b22", "#FFFF00", "#00FF00"))+ theme_classic()+ theme(legend.position="none")+ labs(x = "Genetic Cluster")+ labs(y = "Heterozygosity")+ labs(title = "Multilocus Heterozygosity per Region")

#vcftools F visualize
file <-read.csv("vcftools_F_lenRef_LD_100_bi.csv")
c <- ggplot(file, aes(x = region, y = F, fill=region))+ 
  geom_boxplot(varwidth = TRUE)
c
c+scale_x_discrete(limits=c("West", "South", "East"))+scale_fill_manual(values=c("#228b22", "#FFFF00", "#00FF00"))+ theme_classic()+ theme(legend.position="none")+ labs(x = "Genetic Cluster")+ labs(y = "F")+ labs(title = "Inbreeding Coefficient per Region")

#sMLH visualize
file <-read.csv("het_lenRef_LD_100_bi.csv")
c <- ggplot(file, aes(x = region, y = het, fill=region))+ 
  geom_boxplot(varwidth = TRUE)
c
c+scale_x_discrete(limits=c("West", "South", "East"))+scale_fill_manual(values=c("#228b22", "#FFFF00", "#00FF00"))+ theme_classic()+ theme(legend.position="none")+ labs(x = "Genetic Cluster")+ labs(y = "Heterozygosity")+ labs(title = "Standardized Multilocus Heterozygosity per Region")

###Calculating Mean and SE###
file <-read.csv("directional_fst_lenRef_LD_morethan2.csv")
svw <- subset(file, file$Region == "SvW")
sve <- subset(file, file$Region == "SvE")
evw <- subset(file, file$Region == "EvW")
mean(svw$Fst)
mean(sve$Fst)
mean(evw$Fst)
sd(evw$Fst, na.rm=TRUE) /
sqrt(length(evw$Fst[!is.na(evw$Fst)]))
sd(svw$Fst, na.rm=TRUE) /
sqrt(length(svw$Fst[!is.na(svw$Fst)]))
sd(sve$Fst, na.rm=TRUE) /
sqrt(length(sve$Fst[!is.na(sve$Fst)]))
