
### Load your necessary packages
library(LEA)


####################
##### Run sNMF #####
####################
# sNMF will consist of two steps
# 1. imputation of missing sites, we can impute missing sites randomly
# Or we can use collaborative filtering to impute with the most likely genotype
# 2. We will estimate our final ancestry proportions using an imputed dataset

obj.snmf <- snmf(Platy_reduced.geno, K = 1:10, rep = 1, alpha = 100, CPU = 4, entropy = T,  project = "new")
plot(obj.snmf, cex = 1.2, col = "navy", pch = 19) ### Inspect to choose K, look for the minimum value 

k = 3 ### Change me, based on the inspection of the obj.snmf plot 

obj <- snmf(Platy_reduced.geno, K = k, rep = 50, alpha = 100, CPU = 4, entropy = T,  project = "new")
ce = cross.entropy(obj, K = k)
best = which.min(ce)

### Impute your dataset ### 
dat.complete = Dat9

impute(obj, Platy_reduced.geno, method = 'mode', K=k, run = best)
dat.complete = read.lfmm(Platy_reduced.lfmm)
colnames(dat.complete) <- colnames(Dat9)
write.lfmm(output.file = 'Platy_reduced.lfmm', R = dat.complete)
lfmm2geno('Platy_reduced.lfmm')

### Run final sNMF ### 
obj.snmf <- snmf(Platy_reduced_imputed.geno, K = 1:10, rep = 1, alpha = 100, CPU = 4, entropy = T,  project = "new")
plot(obj.snmf, cex = 1.2, col = "navy", pch = 19) ### Inspect to choose K, look for the minimum value 

k = 3 ### Change me, based on the inspection of the obj.snmf plot 

obj2 <- snmf(Platy_reduced_imputed.geno, K = k, rep = 50, alpha = 100, CPU = 4, entropy = T,  project = "new")

# Get the best run for plotting 
ce = cross.entropy(obj2, K = k)
best = which.min(ce)

###################
##### Plot it #####
###################
# Set your colors
mypalette <- c("Forestgreen", "Yellow", "Limegreen",  "Gray", "Black")

barchart(obj2, K = k, run = best,border = NA, space = 0,
         col = mypalette,xlab = "Individuals",ylab = "Ancestry proportions",
         main = "Ancestry matrix") -> bp
axis(1, at = 1:length(bp$order),labels = bp$order, las=1,cex.axis = .4)


### Repeat changing the K to 4 and 5

