This folder contains data and scripts that were used in Farleigh et al., 2021 "The effects of climate and demographic history in shaping genomic variation across populations of the Desert Horned Lizard (Phrynosoma platyrhinos)"

A dedicated subdirectory exists for each analysis performed, in each subdirectory you will find a script or .txt file that will allow you to replicate the analyses performed in the study. Many of the analyses (those performed in R) use the same VCF file which can be found in the subdirectory VCF_files.
Below is a list of the subdirectories and the files they contain

VCF_files = lenRefgenome.vcf (file with 8,094 SNPs, produced by dDocent, used in a majority of R analyses), lenRefgenome_LD_100_bi.recode.vcf (file with no missing data, used in heterozygosity calculations), NoSelectedSNPs.recode.vcf (file with outlier and GEA candidates removed, used in Moments demographic modeling)
sNMF = Platy_reduced.geno (file used in sNMF analysis), Platy_reduced.lfmm (file produced during sNMF analysis, used in RDA), Platy_sNMF.R (script to perform sNMF analysis)
RDA = HLReferenceSamples_EnvdataRDA.csv (Locality, genetic cluster assignment, and environmental data for each sample), Platy_reduced_imputed.lfmm (lfmm file used in RDA), RDAreference.R (script to perform RDA), SelectedVars.csv (Selected environmental variables used in RDA)
Pcadapt = HLReferenceSamples_EnvdataRDA.csv (Locality, genetic cluster assignment, and environmental data for each sample), lenRef.pcadapt (files used in pcadapt analysis), Refpcadapt.R (script to perform pcadapt analysis)
Moments = 3pop and 4pop subdirectories, each contains an fs (used in demographic modeling), popmap (used to assign individuals to populations), and pipeline (script to run analyses), models are available at https://github.com/kfarleigh/Moments
IQ-tree = IQ-treecommand.txt (command to run IQ-tree), Tree_Rerun.phy (phylip file used in IQ-tree analysis)
Heterozygosity = Platy_MLH.R (R script to perform heterozygosity calculations)
BPP = 3pop and 4pop subdirectories, each contains a .ctl file which tells BPP how to perform the analysis, .imap file which assigns individuals to populations, and .txt which contains the genetic data, Bpp_command.txt (example command to run BPP)
AIS = gt_lenRef_AIS_v4.txt (input file used for Alleles in Space)
Fst_privatealleles = Fst_paf.R (script to perform Fst and private alleles analysis, also including plotting)