setwd("G:/HornedLizard/RDA/Reference")

library(psych)
library(vegan)
library(trio)
library(LEA)
library(dplyr)
library(vcfR)
library(ggplot2)

RDA_Impute<-function(x){replace(x, is.na(x), as.numeric(names(which.max(table(x)))))}
#writes a basic function to impute the most common genotype for missing data 

###########################
##### !!! Read ME !!! #####
###########################

# This script was adapted from Forester et al., 2018 
# https://popgen.nescent.org/2018-03-27_RDA_GEA.html
# For rda analysis the genotype matrix has to been complete (No NA's) and values can be 0, 1, or 2.
# This is the same format as in LEA
# So what we'll do is take the imputed lfmm file and use that 
# See the LEA tutorial by Olivier Francois or Frichot et al., 2015 for more information  regarding formatting/imputation

# For rda, we will use an enviromental csv with populations and coordinates for downstream visualization purposes

###############################################
##### Bring in files and check formatting #####
###############################################

Genotypes<-read.lfmm("Platy_reduced_imputed.lfmm")
EnvVars<-read.csv("HLReferenceSamples_EnvdataRDA.csv")

sum(is.na(Genotypes))
9 %in% Genotypes
# or
any(Genotypes == 9)
# checks for any NA's or 9's in your dataframe

str(EnvVars)
EnvVars$Samples<-as.character(EnvVars$Samples)
# check the structure of your environmental file and change Samples to characters

Samples<-EnvVars$Samples
row.names(Genotypes)<- Samples
row.names(Genotypes)
identical(rownames(Genotypes), EnvVars$Samples)
# makes sure that your samples match each other in your genotypes and environmental variables


################################################################
##### Check for Correlation between Environmental Variables#####
################################################################

# with RDA we have to check for correlation between environmental predicts as to not bias our results

pairs.panels(EnvVars [,5:23 ], scale = TRUE)
Correlation<-cor.plot(EnvVars [,5:23], xlas =  2)
Correlation<-cor.plot(EnvVars [,5:23], xlas =  2, cex.axis = 0.75, MAR = 8)
# look at correlation between environmental variables, when using 10 or less you can use the paris plot
# otherwise use the correlation plot as it is easier to visualize with more variables

StrongCorr<-which(Correlation >= 0.7, arr.ind = TRUE)
NoCorr<-which(Correlation < 0.7, arr.ind = TRUE)
# pulls out which variables have strong or weaker correlations with each other 

Pred<-subset( Correlation < 0.7)
PredSC<-subset( Correlation >= 0.7)
# pulls out which variables have strong or weaker correlations with each other
# returns a logical vector (True/False)

write.csv(PredSC, "StrongCorrelation.csv", row.names = TRUE)

SelectedVars<-select(EnvVars,5,8,22,23)
colnames(SelectedVars) <- c("AMT","TS","PWQ","PCQ")
#pull out our selected variables
#rename columns so they are easier to read

pairs.panels(SelectedVars, scale = TRUE)
Env_corr<- cov2cor(cov(SelectedVars))
abs(Env_corr) >= 0.7
# plots a paris panel of variables
# provides a logical return of whether or not your variable are correlated

write.csv(SelectedVars, file = "SelectedVars.csv")
# write it out as a file

########################
##### Run your RDA #####
########################

HL_rda<- rda(Genotypes ~ ., data = SelectedVars, scale = TRUE)
HL_rda
# runs the rda and looks at it

Rsquared<-RsquareAdj(HL_rda)
Rsquared
# look at the rsquared and adjusted rsquared values

summary(eigenvals(HL_rda, model = "constrained"))
# provides a summary of the eigenvalues for each axis

screeplot(HL_rda, main = "Eigenvalues from RDA", col = "navy")
# plots a scree plot of the eigenvalues

Fullsig <- anova.cca(HL_rda, parallel=getOption("mc.cores"))
Fullsig
# test the significance of the rda
# displays results

Axissig <- anova.cca(HL_rda, by="axis", parallel=getOption("mc.cores"))
Axissig
# find which constrained axes are significant
# this can take awhile 

vif.cca(HL_rda)
# checks the variance inflation factors
# the lower the better

#############################
# lets make some cool plots

Pop<- EnvVars$Population
bg <- c("#228b22","#FFFF00","#00FF00","#a6cee3","#33a02c","#e31a1c")
# pull out populations and get some colors

###############
# axes 1 & 2
plot(HL_rda, type="n", scaling=3) 
points(HL_rda, display="sites", pch=21, cex=1.3, col="gray32", scaling=3, bg=bg[Pop]) #displays individuals
text(HL_rda, scaling=3, display="bp", col="356689", cex=1.25)  #displays predictors
legend("topleft", legend=levels(Pop), bty = "o", col="gray32", pch=21, cex=1, pt.bg=bg, title = "Region")
Ind_plot = recordPlot()
###############
# axes 1 & 3

plot(HL_rda, type="n", scaling=3, choices = c(1,3))
points(HL_rda, display="species", pch=20, cex=0.7, col="gray32", scaling=3, choices = c(1,3)) #displays SNPs
points(HL_rda, display="sites", pch=21, cex=1.3, col="gray32", scaling=3, bg=bg[Pop], choices = c(1,3)) #displays individuals
text(HL_rda, scaling=3, display="bp", col="#0868ac", cex=1, choices = c(1,3))  #displays predictors
legend("bottomright", legend=levels(Pop), bty="n", col="gray32", pch=21, cex=1, pt.bg=bg) #adds legend

#########################
##### The Prettiest #####
#########################

scor = scores(HL_rda, display=c("sp", "cn", "bp", "sites"), scaling=3, choices = c(1,2,3,4))
# Pull the scores from the RDA (what to plot)

Pop_Plot = data.frame(Pop)
colnames(Pop_Plot) = c("Region")
mypalette = c("Forestgreen", "Yellow", "Limegreen")

Base_Plot = plot(HL_rda)
mult <- attributes(Base_Plot$biplot)$arrow.mul # Predictors
Predictor_scor = data.frame(scor$biplot)
centroids = data.frame(scor$centroids)
Snps_scor = data.frame(scor$species) # SNPs
Ind_scor = data.frame(scor$sites) # Individuals
# Pull out your plot components

Individual_plot = ggplot() + 
  geom_vline(xintercept = 0,linetype = "dashed") +
  geom_hline(yintercept = 0, linetype = "dashed") +
  geom_point(data = Ind_scor, aes(x = RDA1, y = RDA2, fill = factor(Pop_Plot$Region)), 
             shape = 21, size = 2.25) +
  geom_segment(data = Predictor_scor,
               aes(x = 0, xend = mult * RDA1,
                   y = 0, yend = mult * RDA2),
               arrow = arrow(length = unit(0.25, "cm")), colour = "black", size = 1) + 
  scale_fill_manual(values = mypalette, name = "Region") +
  scale_color_manual(values = c("black")) +
  theme(legend.position = c(0.1, 0.8), 
        legend.background = element_rect(color = "black",  size = 1, linetype = "solid"),
        panel.background = element_blank(), 
        panel.border = element_rect(colour = "black", fill = "transparent", size = 1))

################################
##### Testing for Outliers #####
################################

outliers <- function(x,z){
  lims <- mean(x) + c(-1, 1) * z * sd(x)     # find loadings +/-z sd from mean loading     
  x[x < lims[1] | x > lims[2]]               # locus names in these tails
}

# writes a function identify outliers

load.rda <- scores(HL_rda, choices=c(1:4), display="species") 
# extract SNP loadings from the significant axes

hist(load.rda[,1], main="Loadings on Axis 1", xlab = NULL)
hist(load.rda[,2], main="Loadings on Axis 2", xlab = NULL)
hist(load.rda[,3], main="Loadings on Axis 3", xlab = NULL)
hist(load.rda[,4], main="Loadings on Axis 4", xlab = NULL)
# plot histograms of the loadings

cand1 <- outliers(load.rda[,1],2.5)
cand2 <- outliers(load.rda[,2],2.5)
cand3 <- outliers(load.rda[,3],2.5)
cand4 <- outliers(load.rda[,4],2.5)
# apply the function you wrote to each significant axis
# the number by itself indicates how many standard deviations to go
# choosing higher numbers i.e. 3 looks for loci under strong selection, lesser i.e. 2 will be more lenient

ncand <- length(cand1) + length(cand2) +length(cand3) + length(cand4)
ncand
# lets see how many outliers we have

###################################
##### Organize into Dataframe #####
###################################

cand1 <- cbind.data.frame(rep(1,times=length(cand1)), names(cand1), unname(cand1))
cand2 <- cbind.data.frame(rep(1,times=length(cand2)), names(cand2), unname(cand2))
cand3 <- cbind.data.frame(rep(1,times=length(cand3)), names(cand3), unname(cand3))
cand4 <- cbind.data.frame(rep(1,times=length(cand4)), names(cand4), unname(cand4))
colnames(cand1) <- colnames(cand2) <- colnames(cand3)<- colnames(cand4)<- c("axis","snp","loading")
cand <- rbind(cand1, cand2, cand3, cand4)
cand$snp <- as.character(cand$snp)

# Now we combine this data with our environmental variables

foo <- matrix(nrow=(ncand), ncol=4)
colnames(foo) <- c("AMT","TS","PWQ","PCQ")
for (i in 1:length(cand$snp)) {
  nam <- cand[i,2]
  snp.gen <- Genotypes[,nam]
  foo[i,] <- apply(SelectedVars,2,function(x) cor(x,snp.gen))
}

cand <- cbind.data.frame(cand,foo)

#################################
##### Investigate Canidates #####
#################################

length(cand$snp[duplicated(cand$snp)])
# look for any canidate SNPs

foo <- cbind(cand$axis, duplicated(cand$snp)) 
table(foo[foo[,1]==1,2])
# check for duplicates on axis 1

table(foo[foo[,1]==2,2])
# check for duplicates on axis 2

cand <- cand[!duplicated(cand$snp),]
# remove any duplicate SNPs

for (i in 1:length(cand$snp)) {
      bar <- cand[i,]
      cand[i,8] <- names(which.max(abs(bar[4:7]))) # makes a column with predictor
      cand[i,9] <- max(abs(bar[4:7])) } #makes a column with correlation
# Will tell us which predictor each SNP is associated with

colnames(cand)[8] <- "predictor"
colnames(cand)[9] <- "correlation"
# Adds names to the columns we just made

table(cand$predictor) 
# Lets see which variables our data are most associated with

write.csv(cand, "RefCanidateSNPs_Full.csv")

###############################
##### Let's Plot the SNPs #####
###############################

sel <- cand$snp
env <- cand$predictor
# take out the SNPs and predictors

env[env=="AMT"] <- '#e31a1c'
env[env=="TS"] <- '#ffa500'
env[env=="PWQ"] <- '#a6cee3'
env[env=="PCQ"] <-  '#2b94db'

# add colors for plotting 

col.pred <- rownames(HL_rda$CCA$v)
# get SNP Names

for (i in 1:length(sel)) {          
  foo <- match(sel[i],col.pred)
  col.pred[foo] <- env[i]
}

# color code the canidate SNPs

col.pred[grep("V",col.pred)] <- '#f1eef6'
# add a color to the non-canidate SNPs

empty <- col.pred
empty[grep("#f1eef6",empty)] <- rgb(0,1,0, alpha=0) # transparent
empty.outline <- ifelse(empty=="#00FF0000","#00FF0000","gray32")
bg1 <- c('#e31a1c', '#ffa500','#a6cee3','#2b94db')
# more visualizaton prep


#####################
##### Plot SNPs #####
#####################

plot(HL_rda, type="n", scaling=3, xlim=c(-1,1), ylim=c(-1,1))
points(HL_rda, display="species", pch=21, cex=1, col="gray32", bg=col.pred, scaling=3)
points(HL_rda, display="species", pch=21, cex=1, col=empty.outline, bg=empty, scaling=3)
text(HL_rda, scaling=3, display="bp", col="356689", cex=1.25)  #displays predictors

legend("topleft", legend= c("AMT", "TS", "PWQ", "PCQ"), bty="n", col="gray32", pch=21, cex=1, pt.bg=bg) #adds legend
# adds legend

##################
# axis 1 & 3
plot(HL_rda, type="n", scaling=3, xlim=c(-1,1), ylim=c(-1,1), choices = c(1,3))
points(HL_rda, display="species", pch=21, cex=1, col="gray32", bg=col.pred, scaling=3, choices = c(1,3))
points(HL_rda, display="species", pch=21, cex=1, col=empty.outline, bg=empty, scaling=3, choices = c(1,3))
text(HL_rda, scaling=3, display="bp", col="356689", cex=1.25, choices = c(1,3))  #displays predictors

legend("bottomright", legend= c("AMT", "TS", "PWQ", "PCQ"), bty="n", col="gray32", pch=21, cex=1, pt.bg=bg) #adds legend
# adds legend

##################
# axis 1 & 4
plot(HL_rda, type="n", scaling=3, xlim=c(-1,1), ylim=c(-1,1), choices = c(1,4))
points(HL_rda, display="species", pch=21, cex=1, col="gray32", bg=col.pred, scaling=3, choices = c(1,4))
points(HL_rda, display="species", pch=21, cex=1, col=empty.outline, bg=empty, scaling=3, choices = c(1,4))
text(HL_rda, scaling=3, display="bp", col="356689", cex=1.25, choices = c(1,4))  #displays predictors

legend("bottomright", legend= c("AMT", "TS", "PWQ", "PCQ"), bty="n", col="gray32", pch=21, cex=1, pt.bg=bg) #adds legend
# adds legend

############################
##### Multipanel Plots #####
############################

#### Compare Individuals]

par(mar = c(0, 0, 0, 0), oma = c(4, 4, 0.5, 0.5))
layout.matrix <- matrix(c(2, 1, 3), nrow = 1, ncol = 3)
layout(mat = layout.matrix) 
bg <- c("#228b22","#FFFF00","#00FF00","#a6cee3","#33a02c","#e31a1c")

par(mfrow = c(1, 3))
par(cex = 0.8)
par(mar = c(0, 0, 0, 0), oma = c(4, 4, 0.5, 0.5))
par(tcl = -0.25)
par(mgp = c(2, 0.6, 0))

# The Full Plot

plot(HL_rda, type="n", scaling=3) 
points(HL_rda, display="sites", pch=21, cex=1.3, col="gray32", scaling=3, bg=bg[Pop]) #displays individuals
text(HL_rda, scaling=3, display="bp", col="356689", cex=1)  #displays predictors
legend(x = -4, y = 9, legend=levels(Pop), bty = "o", col="gray32", pch=21, cex=1, pt.bg=bg, title = "Region")


#### Compare Candidate Snps
par(mfrow = c(1, 3))
par(cex = 0.8)
par(mar = c(0, 0, 0, 0), oma = c(4, 4, 0.5, 0.5))
par(tcl = -0.25)
par(mgp = c(2, 0.6, 0))


# SNP axis 1 and 2

# Full
plot(HL_rda, type="n", scaling=3, xlim=c(-1,1), ylim=c(-1,1))
points(HL_rda, display="species", pch=21, cex=1, col="gray32", bg=col.pred, scaling=3)
points(HL_rda, display="species", pch=21, cex=1, col=empty.outline, bg=empty, scaling=3)
text(HL_rda, scaling=3, display="bp", col="356689", cex=1.25)  #displays predictors
legend("topleft", legend= c("AMT", "TS", "PWQ", "PCQ"), bty="n", col="gray32", pch=21, cex=1, pt.bg=bg)


# SNP axis 1 and 3

# Full 
plot(HL_rda, type="n", scaling=3, xlim=c(-1,1), ylim=c(-1,1), choices = c(1,3))
points(HL_rda, display="species", pch=21, cex=1, col="gray32", bg=col.pred, scaling=3, choices = c(1,3))
points(HL_rda, display="species", pch=21, cex=1, col=empty.outline, bg=empty, scaling=3, choices = c(1,3))
text(HL_rda, scaling=3, display="bp", col="356689", cex=1.25, choices = c(1,3))  #displays predictors
legend("bottomright", legend= c("AMT", "TS", "PWQ", "PCQ"), bty="n", col="gray32", pch=21, cex=1, pt.bg=bg)


# SNP axis 1 and 4

# Full
plot(HL_rda, type="n", scaling=3, xlim=c(-1,1), ylim=c(-1,1), choices = c(1,4))
points(HL_rda, display="species", pch=21, cex=1, col="gray32", bg=col.pred, scaling=3, choices = c(1,4))
points(HL_rda, display="species", pch=21, cex=1, col=empty.outline, bg=empty, scaling=3, choices = c(1,4))
text(HL_rda, scaling=3, display="bp", col="356689", cex=1.25, choices = c(1,4))  #displays predictors
legend("bottomright", legend= c("AMT", "TS", "PWQ", "PCQ"), bty="n", col="gray32", pch=21, cex=1, pt.bg=bg)

